$(document).ready(function () {
  document.querySelector('#CinemaSeatMap').getSVGDocument().getElementById('E10').setAttribute('fill', 'red');
});
